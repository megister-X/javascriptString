
const ecoController = {
    index: async (req, res) =>{
        res.render('eco/economie');
    }
}

module.exports = ecoController;