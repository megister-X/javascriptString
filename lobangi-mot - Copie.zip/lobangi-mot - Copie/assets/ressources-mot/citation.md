## citations :
    [
        {
            citationId :
            auteur : 
            contenu :
            contexte? :
            date? :
        }
    ]