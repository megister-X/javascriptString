

#
https://cdn.socket.io/4.7.4/socket.io.min.js

# server delivery
npm install sqlite sqlite3

# cluster adapter
npm install '@socket.io/cluster-adapter'
⌉⌉⌉
npm i '@socket.io/admin-ui'