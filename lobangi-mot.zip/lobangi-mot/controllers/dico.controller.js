
const dicoController = {
    index: async (req, res) =>{
        res.render('dico/dictionnaire');
    }
    
}

module.exports = dicoController;