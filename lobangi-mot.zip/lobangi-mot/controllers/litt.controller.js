
const littController = {
    index: async (req, res) =>{
        res.render('litt/litterature');
    }
}

module.exports = littController;