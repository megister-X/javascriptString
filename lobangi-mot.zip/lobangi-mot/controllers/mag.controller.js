
const magController = {
    index: async (req, res) =>{
        res.render('mag/magazine');
    }
}

module.exports = magController;