

## verbe
```
→ verbe
→ mode [
    "indicatif",
    "subjonctif",
    "conditionnel",
    "impératif",
    "infinitif",
    "participe",
    "gérondif"
]

"indicatif" : [
    "présent",
    "passé composé",
    "imparfait",
    "plus-que-parfait",
    "passé simple",
    "passé antérieur",
    "futur simple",
    "futur antérieur"
]
"subjonctif" : [
    "présent",
    "imparfait",
    "passé",
    "plus-que-parfait"
]
"conditionnel" : [
    "présent",
    "passé première forme",
    "passé deuxième forme"
]
"impératif" : [
    "présent",
    "passé"
]
"infinitif" : [
    "présent",
    "passé"
]
"participe" : [
    "présent",
    "passé"
]
"gérondif" : [
    "présent",
    "passé"
]
→ 
→ 
```

## terminaisons


conditionnel

    Quatre modes personnels
        L'indicatif
        Le subjonctif
        Le conditionnel
        L'impératif
    Trois modes impersonnels
        L'infinitif
        Le participe
        Le gérondif