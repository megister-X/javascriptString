
## auteur
→ auteurId
→ dateNaissance
→ prenom
→ nom
→ pseudonyme