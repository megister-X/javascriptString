<!-- format csv -->

## traduction : [
    {
        'motId', 
        'mot(lingala)',
        'français', 
        'kikongo', 
        'tshiluba', 
        'kiswahili', 
        'kingbandi'
    }
]