
## proverbe : 
[
    {
        proverbeId : 
        source : auteur || origine :
        contenu :
    }
]