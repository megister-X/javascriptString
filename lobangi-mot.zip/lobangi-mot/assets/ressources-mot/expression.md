##expression : 
[
    {
        expressionId :
        source : auteur || origine :
        contenu :
    }
]