
#

## mot
```
→ motId : automatiser
→ mot : 
→ classe : [
    'le nom', 
    'l’adjectif',
    'le verbe',
    'l’adverbe',
    'le déterminant',
    'le pronom', 
    'la préposition',
    'la conjonction', 
    'l’interjection' 
]
→ forme : ['variable', invariable]
→ genre : ['masculin', 'feminin', 'neutre']
→ nombre : ['pluriel', 'singulier']
→ phonétique : 
→ prononciations : [
    {
        lieu : 
        prononciation :
    }
]
→ étymologie : [
    {
        source: 
        explication :
    }
]

→ sens : 
    [
        {
            ↠ origine : 
            ↠ definition :
            ↠ synonyme :
            ↠ exemple :
        }
    ]
→ synonyme : []
→ contraire : []
```

### autres tables
```
→ traduction : [
    'français', 'kikongo', 'tshiluba', 'kiswahili', 'kingbandi'
]
→ citation : 
    {
        auteur : 
        contenu :
        contexte? :
        date? :
    }
→ expression : 
    {
        source : auteur || origine :
        contenu :
    }
→ proverbe : 
    {
        source : auteur || origine :
        contenu :
    }
→ poème : 
    {
        titre ? :
        auteur? :
        contenu :
        date :
        ouvrage :
    }
```


