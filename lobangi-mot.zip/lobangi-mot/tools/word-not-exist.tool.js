const logError = () => console.log('Le mot n\'est pas dans la base de données 🥺');
module.exports= logError;