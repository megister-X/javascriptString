

## Endpoint

get : './'
post : './'
put : './id(^[0-9]d{8})'
update : './id'
patch : './id'
delete : './:id'