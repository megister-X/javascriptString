const recipeService = require('../services/recipe.service');
const mockup = require('./mockups/recipes.json');

const homeController = {
    index: async (req, res)=>{
        // Obtenir le dernier element ajouté

        const recipes = await recipeService.getAll();

        const ajout = recipes[recipes.length - 1];
        let random = Math.floor(Math.random() * recipes.length );

        const jour =  recipes[random];
    
        // console.log(recipes.length);

        res.render('home/index', { ajout, jour });
    },
    about: async (req, res)=>{
        res.render('home/about');
    },
    contact: async (req, res)=>{
        res.render('home/contact');
    },
    dashboard: async (req, res)=>{
        res.render('home/dashboard');
    }
}

module.exports = homeController;