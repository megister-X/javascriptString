
// upload file library
const multer  = require('multer');
const { recipeValidator } = require('../validators/recipe.validator');
const upload = multer({ dest: './database/uploads/' })


const recipeUpload = async () =>{
    let data;
        try {
            data = await recipeValidator.noUnknown().validate(req.body, { abortEarly: false });
        }
        catch(error) {
            console.log(error);
        }

    return upload.single({recipeimg: `${data.recipeimg}`});
}

module.exports = recipeUpload;