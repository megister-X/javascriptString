'use strict'

function myFunction() {

  console.log("ma fonction responsive")
    var x = document.getElementById("myMenu");
    if (x.className === "top-menu") {
      x.className += " responsive";
    } else {
      x.className = "top-menu";
    }
  }

  