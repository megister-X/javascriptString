
if(2 <= 6){
    console.log('absurde');
    =>
    
}