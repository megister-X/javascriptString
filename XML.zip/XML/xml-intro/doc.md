#_-_# Transaction Data

#_-_# Thousands of XML formats exist, in many different industries, to describe day-to-day data transactions:

    ## Stocks and Shares
    ## Financial transactions
    ## Medical data
    ## Mathematical data
    ## Scientific measurements
    ## News information
    ## Weather services

There are 5 pre-defined entity references in XML:
&lt; < less than
&gt; > greater than
&amp; & ampersand
&apos; ' apostrophe
&quot; " quotation mark

Style Example Description
Lower case <firstname> All letters lower case
Upper case <FIRSTNAME> All letters upper case
Snake case <first_name> Underscore separates words (commonly used in SQL databases)
Pascal case <FirstName> Uppercase first letter in each word (commonly used by C programmers)
Camel case <firstName> Uppercase first letter in each word except the first (commonly used in JavaScript)

########################

## XSLT

    XPath is a syntax for defining parts of an XML document
    XPath uses path expressions to navigate in XML documents
    XPath contains a library of standard functions
    XPath is a major element in XSLT and in XQuery
    XPath is a W3C recommendation

###################################################
XLINKS
##--------------------##
Attribute Value Description

## xlink:actuate onLoad

onRequest
other
none Defines when the linked resource is read and shown:

    onLoad - the resource should be loaded and shown when the document loads
    onRequest - the resource is not read or shown before the link is clicked

## xlink:href URL Specifies the URL to link to

## xlink:show embed

new
replace
other
none Specifies where to open the link. Default is "replace"

## xlink:type simple

extended
locator
arc
resource
title
none

##

<?xml version="1.0" encoding="UTF-8"?>

<!DOCTYPE note [
<!ENTITY nbsp "&#xA0;">
<!ENTITY writer "Writer: Donald Duck.">
<!ENTITY copyright "Copyright: W3Schools.">

]>

<note>
<to>Tove</to>
<from>Jani</from>
<heading>Reminder</heading>
<body>Don't forget me this weekend!</body>
<footer>&writer;&nbsp;&copyright;</footer>
</note> 
##
----------------
##
The Building Blocks of XML Documents

Seen from a DTD point of view, all XML documents are made up by the following building blocks:

    Elements
    Attributes
    Entities
    PCDATA
    CDATA

##

---

##

The attribute-type can be one of the following:
Type Description
CDATA The value is character data
(en1|en2|..) The value must be one from an enumerated list
ID The value is a unique id
IDREF The value is the id of another element
IDREFS The value is a list of other ids
NMTOKEN The value is a valid XML name
NMTOKENS The value is a list of valid XML names
ENTITY The value is an entity
ENTITIES The value is a list of entities
NOTATION The value is a name of a notation
xml: The value is a predefined xml value

##

---

##

The attribute-value can be one of the following:
Value Explanation
value The default value of the attribute
#REQUIRED The attribute is required
#IMPLIED The attribute is optional
#FIXED value The attribute value is fixed

##
