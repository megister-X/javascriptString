import CategoryPage from "../../containers/category-page/category-page";

const NewsPage = () => {


    return(
        <div>
        <div>
            <h2>News</h2>
        </div>
            <CategoryPage />

        </div>
    )
}

export default NewsPage;