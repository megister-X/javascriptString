


const DonatePage = () => {




    return (

        <>
        
            <h2>Donate</h2>
        
        </>
    )
}

export default DonatePage;