import CategoryPage from "../../containers/category-page/category-page";



const SocietyPage = () => {


    return(
        <div>
            <h2>Society</h2>
            <CategoryPage />
        </div>
    )
}

export default SocietyPage;