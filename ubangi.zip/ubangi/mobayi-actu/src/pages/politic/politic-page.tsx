import CategoryPage from "../../containers/category-page/category-page";

const PoliticPage = () => {


    return(
        <div>
            <h2>Politic</h2>
         <CategoryPage />
        </div>
    )
}

export default PoliticPage;