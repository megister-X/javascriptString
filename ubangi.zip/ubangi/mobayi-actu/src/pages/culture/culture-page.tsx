import CategoryPage from "../../containers/category-page/category-page";


const CulturePage = () => {


    return(
        <div>
            <h2>Culture</h2>
            <CategoryPage />
        </div>
    )
}

export default CulturePage;