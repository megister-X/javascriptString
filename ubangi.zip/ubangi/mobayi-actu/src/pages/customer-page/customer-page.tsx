

const CustomerPage = () => {

    return (
        <>
            <h1>Customer</h1>
        </>
    )
}

export default CustomerPage;