import CategoryPage from "../../containers/category-page/category-page";

const SciencePage = () => {


    return(
        <div>
            <h2>Science</h2>
            <CategoryPage />
        </div>
    )
}

export default SciencePage;