

const AboutPage = () => {

    return (
        <>
            <h1>A propos</h1>
        </>
    )
}

export default AboutPage;