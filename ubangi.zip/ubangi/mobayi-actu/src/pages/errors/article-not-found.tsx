
const ArticleNotFoundPage = () => {

    return (
        <div>
        <h2>Le Livre existe pas pffff...</h2>
        </div>
    )
}
export default ArticleNotFoundPage;