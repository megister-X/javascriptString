const ContactPage = () => {

    return (
        <>
            <h1>Contact</h1>
        </>
    )
}

export default ContactPage;