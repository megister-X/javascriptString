import CategoryPage from "../../containers/category-page/category-page";

const EconomyPage = () => {


    return(
        <div>
            <h2>Economy</h2>
            <CategoryPage />
        </div>
    )
}

export default EconomyPage;