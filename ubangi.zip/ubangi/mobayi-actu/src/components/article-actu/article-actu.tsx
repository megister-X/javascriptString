

const ArticleActu = () => {


    return(
        <article>
            <h2>Mon article</h2>
            <h3>

            </h3>
            <figure>
                <img src="" alt="mon image" />
            </figure>
        </article>
    )
}

export default ArticleActu;