

const ArticleAdvert = () => {


    return(
        <article>

        </article>
    )
}

export default ArticleAdvert;