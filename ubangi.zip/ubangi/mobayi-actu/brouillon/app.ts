
// script.js
function openImg() {
    const image = document.getElementById('image');
    const imageUrl = image.src;
    window.open(imageUrl, '_blank');
}
