


## Général
-> https://siecledigital.fr/tag/api/
-> https://rapidapi.com/guides/call-apis-using-axios-in-typescript

## News
https://newsapi.org/

https://aylien.com/product/news-api/demo

##  Economy
-> https://exchangeratesapi.io/

## Environnement
-> https://www.sogefi-sig.com/geoservices-apis-wms/

## Météo
-> https://www.getambee.com/api/weather?utm_term=api%20weather&utm_campaign=Weather+API&utm_source=adwords&utm_medium=ppc&hsa_acc=9773927819&hsa_cam=10878269195&hsa_grp=112779988011&hsa_ad=555934377264&hsa_src=g&hsa_tgt=kwd-353485000796&hsa_kw=api%20weather&hsa_mt=e&hsa_net=adwords&hsa_ver=3&gad_source=1&gclid=Cj0KCQjwltKxBhDMARIsAG8KnqVASolX6cqwpd-ONZ7g8LukY-1YxZFi09B2-6tG18-ocNjSz01Qa8MaAoZ9EALw_wcB

-> https://openweathermap.org/api

-> https://open-meteo.com/

-> https://rapidapi.com/blog/access-global-weather-data-with-these-weather-apis/

## technologie
-> https://rapidapi.com/category/Science