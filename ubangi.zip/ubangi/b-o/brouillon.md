if(user=="myusername" && pass="mypassword"){
window.location.href="https://example.com";
}else{
alert("Your username or password is wrong.");
}

