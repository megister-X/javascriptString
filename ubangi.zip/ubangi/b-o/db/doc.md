npm install mongoose
# or
yarn add mongoose
