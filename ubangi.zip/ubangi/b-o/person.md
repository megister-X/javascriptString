# gestionnaire de DB : 
 - https://www.sanity.io/docs/datastore
 - https://strapi.io/



 ## MongoDB
  - Pour les articles, les actualités, les annonces


## SQL postgresql
 - Pour la gestion des utilisateur


## Prototypage
 - https://www.framer.com/academy/topics/cms


#Les API : actualité, sport, culture, technologie, science, économie, finance, entrepreunariat, industrie, agriculture, zoologie, botanique

## La météo
OpenWeather Map : https://openweathermap.org/api

## Les pays
CountryLayer : http://countrylayer.com/

Zippopotam : http://www.zippopotam.us/


# Les API's

```
⇒ https://geekflare.com/fr/global-news-api 
⇒ https://newsapi.org/
⇒ https://www.blogdumoderateur.com/mediastack-api-donnees-actualites-en-temps-reel/
⇒ 
⇒ 
⇒ 
⇒ 

```



## API Actualités
```


```


## API Actualités Météo
```


```


## API Actualités Sport
```


```


## API Actualités Economie
```


```


## API Actualités Technologie
```


```


## API Actualités Ecologie
```


```


## API Actualités People
```


```




