const Blob = require('node-blob');

let myBlob = new Blob(["something"], { type: 'text/plain' });